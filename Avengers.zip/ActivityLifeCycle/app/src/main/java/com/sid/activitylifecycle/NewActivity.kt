package com.sid.activitylifecycle

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class NewActivity : AppCompatActivity(), View.OnClickListener
{
    override fun onClick(v: View?)
    {
        Toast.makeText(this@NewActivity,"We clicked on button to see the toast",Toast.LENGTH_LONG).show()
    }

    lateinit var etMobilenum: EditText
    lateinit var etPass:EditText
    lateinit var btnSign:Button
    lateinit var tvForgot:TextView
    lateinit var tvReg:TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new)

        title="Log In"

        etMobilenum=findViewById(R.id.etMobilenum)
        etPass=findViewById(R.id.etPass)
        btnSign=findViewById(R.id.btnSign)
        tvForgot=findViewById(R.id.tvForgot)
        tvReg=findViewById(R.id.tvReg)

        btnSign.setOnClickListener(this)
    }
}
