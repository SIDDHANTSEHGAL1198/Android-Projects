package com.sid.activitylifecycle

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.icu.text.CaseMap
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class LoginActivity : AppCompatActivity() {

    lateinit var etMobile: EditText
    lateinit var etPassword: EditText
    lateinit var btnLog: Button
    lateinit var tvFrgot: TextView
    lateinit var tvRegister: TextView


    val MobileNumber = "9554108603"
    val passwrd = arrayOf("Tony","Steve","Thor","Strange","Peter","Carol","Wanda","Natasha")

    lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        sharedPreferences=getSharedPreferences(getString(R.string.preference_file_name), Context.MODE_PRIVATE)

        val isLoggedIn=sharedPreferences.getBoolean("isLoggedIn",false)

        setContentView(R.layout.activity_login)

        if(isLoggedIn)
        {
            val intent=Intent(this@LoginActivity, MainActivity::class.java)
            startActivity(intent)
            finish()

        }

        setContentView(R.layout.activity_login)


        title = "Log In"

        etMobile = findViewById(R.id.etMobile)
        etPassword = findViewById(R.id.etPassword)
        btnLog = findViewById(R.id.btnLog)
        tvFrgot = findViewById(R.id.tvFrgot)
        tvRegister = findViewById(R.id.tvRegister)






        btnLog.setOnClickListener {
            val mb = etMobile.text.toString()
            val pass = etPassword.text.toString()


            var nameofAvengers:String


            val intent = Intent(this@LoginActivity, MainActivity::class.java)

            if (MobileNumber == mb)
            {

                if (pass==passwrd[0])
                {

                    nameofAvengers = "Tony"
                    savePreference(nameofAvengers)

                    startActivity(intent)

                }

                else if (pass==passwrd[1])
                {

                    nameofAvengers="Steve"
                    savePreference(nameofAvengers)


                    startActivity(intent)

                }

                else if (pass==passwrd[2])
                {

                    nameofAvengers="Thor"
                    savePreference(nameofAvengers)


                    startActivity(intent)

                }

                else if (pass==passwrd[3])
                {

                    nameofAvengers="Strange"
                    savePreference(nameofAvengers)

                    startActivity(intent)

                }

                else if (pass==passwrd[4])
                {

                    nameofAvengers="Peter"
                    savePreference(nameofAvengers)


                    startActivity(intent)

                }

                else if (pass==passwrd[5])
                {

                    nameofAvengers="Carol"
                    savePreference(nameofAvengers)


                    startActivity(intent)

                }

                else if (pass==passwrd[6])
                {

                    nameofAvengers="Wanda"
                    savePreference(nameofAvengers)


                    startActivity(intent)

                }

                else if (pass==passwrd[7])
                {

                    nameofAvengers="Natasha"
                    savePreference(nameofAvengers)

                    startActivity(intent)

                }
                else
                {
                    Toast.makeText(this@LoginActivity, "Incorrect Credentials", Toast.LENGTH_SHORT).show()


                }



            }
            else
            {
                Toast.makeText(this@LoginActivity, "Incorrect Credentials", Toast.LENGTH_SHORT).show()


            }

        }


    }

    override fun onPause() {
        super.onPause()
        finish()
    }

    fun savePreference(title:String)
    {
        sharedPreferences.edit().putBoolean("isLoggedIn", true).apply()
        sharedPreferences.edit().putString("Title", title).apply()

    }
}